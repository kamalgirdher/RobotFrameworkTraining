#---------Added by Kamal for robot integration of AutoHealing of locators--
from SeleniumLibrary.base import LibraryComponent
from pymongo import MongoClient
import json
import collections
import datetime

class Mongodb(LibraryComponent):

    def __init__(self):
        self._dbconnection = None
        self._log=None
        self._db=None
        self._coll=None
        self._logdb=None
        self._logcoll=None
        self._proj=None
        
    def connect_to_mongodb(self, dbHost, dbPort,dbName=None,collName=None):
        client = MongoClient("mongodb://" + str(dbHost) + ":" + str(dbPort) + "/")
        self._dbconnection=client
        if dbName is not None:
            try:
                self._db=client[dbName]
            except:
                raise Exception('DB name not valid.')
            if collName is not None:
                try:
                    self._coll=self._db[collName]
                except:
                    raise Exception('Collection name not valid.')
        else:
            if collName is not None:
                raise Exception('Collection not valid for a None type DB.')
    
    def connect_to_logs(self, dbName,collName):
        if dbName is not None:
            try:
                self._logdb=self._dbconnection[dbName]
            except:
                raise Exception('DB name not valid.')
            if collName is not None:
                try:
                    self._logcoll=self._logdb[collName]
                except:
                    raise Exception('Collection name not valid.')
        else:
            if collName is not None:
                raise Exception('Collection not valid for a None')
        
    
    def use_db_and_coll(self, dbName, collName):
        self._db = self._dbconnection[dbName]
        self._coll = self._db[collName]

    def insert_data(self, jsonObj):
        self._coll.insert_one(jsonObj)
        

    def recordExists(self, recordId):
        return (self._coll.count_documents({'_id': int(recordId)}, limit = 1))
    
    def query(self):
        return self._coll.find().min('_id')
    
    def get_current_locator(self,recordId):
        cur=self._coll.find({'_id':int(recordId)})
        loc=list(x["lastWorkingLoactor"] for x in cur)[0]
        return (loc)
        
    def get_element_details(self,recordId,attr,isJson):
        cur=self._coll.find({'_id':int(recordId)})
        details=list(x[attr] for x in cur)[0]
        if isJson==True:
            return json.loads(details)
        else:
            return details
    
    def set_element_details(self,recordId,elemDetails=None,lastworkinglocator=None):
        if elemDetails==None:
            elemDetails=self.get_element_details(recordId,'elementdetails',True)
        if lastworkinglocator==None:
            lastworkinglocator=self.get_current_locator(recordId)
        self._coll.replace_one({'_id': int(recordId)},{'elementdetails': json.dumps(elemDetails),'lastWorkingLoactor':lastworkinglocator})

            
    def set_default_priority(self,recordId):
        elem_details=self.get_element_details(recordId,'elementdetails',True)
        lastworkinglocator=self.get_current_locator(recordId)
        for a in elem_details.keys():
            for v in elem_details[a].keys():
                elem_details[a][v]={'v':elem_details[a][v],'r':99}
        self.set_element_details(recordId,elem_details,lastworkinglocator)
        
    def add_log(self, locator, status, err):
        logObject=collections.OrderedDict()
        logObject['timestamp']=datetime.datetime.now().strftime("%d-%m-%y %H:%M:%S")
        logObject['loc']=locator
        logObject['status']=status
        logObject['error']=str(err)
        logObject['application']=str(self._proj)
        self._logcoll.insert_one(logObject)
        
    def set_proj(self,proj):
        self._proj=proj
        

#mongoconnection = Mongodb()
#mongoconnection.connect_to_mongodb('localhost',27017,'mydb','mytable')  
#mongoconnection.set_default_priority(1003)
